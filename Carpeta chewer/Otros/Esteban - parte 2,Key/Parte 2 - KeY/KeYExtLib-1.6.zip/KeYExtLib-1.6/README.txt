This is a distribution of freely distributable libraries used in the
KeY system.

For downloading the KeY system refer to http://i12www.ira.uka.de/~key

------------------------------------------------------------------------

The library "Recoder" is protected by the GNU Lesser General Public
License.

See the file "LGPL.txt" that is part of this distribution. 

------------------------------------------------------------------------

The library "Antlr" is in the public domain.

See the file "Antlr.License.txt" that is part of this distribution.

------------------------------------------------------------------------

The library "JUnit" is protected by the IBM Common Public License
Version 0.5

See the file "JUnit.License.txt" that is part of this distribution.

-----------------------------------------------------------------------

The library "javacc" is protected by a BSD like license 

See the file "javacc.License.txt" that is part of this distribution.

-----------------------------------------------------------------------

The library "objenesis" is protected by the Apache License 2.0

See the file "objenesis.License.txt" that is part of this distribution.
